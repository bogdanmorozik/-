from django.db import models
from django.contrib.auth.models import AbstractUser


GENDER_CHOICES = (
    ("Ч", "Чоловік"),
    ("Ж", "Жінка"))


class User(models.Model):
    """Пацієнт"""
    name = models.CharField("ПІБ", max_length=150)
    birthday = models.CharField("Дата народження", max_length=50)
    login = models.EmailField("Емейл")
    phone = models.PositiveIntegerField("Номер телефону", default="380")
    gender = models.CharField("Стать", max_length=20, choices=GENDER_CHOICES, default="Ч")
    password = models.TextField("Пароль", max_length=15)
    adress = models.TextField("Адреса", max_length=150, default=" ")
    photo = models.ImageField("Фото", null=True)
    id = models.PositiveIntegerField("Індетифікаційний код", primary_key=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Пацієнт"
        verbose_name_plural = "Пацієнти"


class Employer(models.Model):
    """Працівник"""
    name = models.CharField("ПІБ", max_length=150)
    birthday = models.CharField("Дата народження", max_length=50)
    login = models.EmailField("Емейл")
    phone = models.PositiveIntegerField("Номер телефону", default="380")
    gender = models.CharField("Стать", max_length=20, choices=GENDER_CHOICES, default="Ч")
    password = models.TextField("Пароль", max_length=15)
    speciality = models.CharField("Спеціальність", max_length=150)
    adress = models.TextField("Адреса", max_length=150, default=" ")
    photo = models.ImageField("Фото", null=True)
    id = models.PositiveIntegerField("Індетифікаційний код", primary_key=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Працівник"
        verbose_name_plural = "Працівники"


class Hospital(models.Model):
    """Лікарня"""
    name = models.CharField("Назва закладу", max_length=150)
    town = models.CharField("Місто", max_length=50, null=True)
    employer = models.ManyToManyField(Employer, verbose_name="Працівники",
                                      related_name="name_employer")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Лікарня"
        verbose_name_plural = "Лікарні"


class Vaccinations(models.Model):
    id_vaccination = models.PositiveIntegerField(primary_key=True, unique=True)
    name_vaccination = models.CharField("Назва вакцини або ліків", max_length=100)

    def __str__(self):
        return self.name_vaccination

    class Meta:
        verbose_name = "Прививка та ліки"
        verbose_name_plural = "Прививки та ліки"


class History(models.Model):
    name_user = models.ForeignKey(User, verbose_name="Пацієнт", on_delete=models.SET_NULL, null=True)
    number = models.PositiveIntegerField(primary_key=True, unique=True)
    name = models.ForeignKey(Hospital, verbose_name="Лікарня", on_delete=models.SET_NULL, null=True)
    name_emloyer = models.ForeignKey(Employer, verbose_name="Працівник", on_delete=models.SET_NULL, null=True)
    vaccinations = models.ForeignKey(Vaccinations, verbose_name="Прививки та ліки", on_delete=models.SET_NULL,
                                     null=True, related_name="name_vaccinations")
    diagnos = models.TextField("Діагноз", null=True)
    diagnos2 = models.TextField("Застосування", null=True)

    def __int__(self):
        return self.number

    class Meta:
        verbose_name = "Історія хвороб"
        verbose_name_plural = "Історія хвороб"


class Vaccina(models.Model):
    town = models.CharField("Місто", max_length=100, default="Луцьк")
    name = models.CharField("ПІБ", max_length=150)
    hospital = models.ForeignKey(Hospital, verbose_name="Заклад", on_delete=models.SET_NULL, null=True)
    day = models.CharField("Дата та час", max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Запис на вакцинацію"
        verbose_name_plural = "Записи на вакцинацію"


class Appointment(models.Model):
    town = models.CharField("Місто", max_length=100, default="Луцьк")
    name = models.ForeignKey(User, verbose_name="Пацієнт", on_delete=models.SET_NULL, null=True)
    hospital = models.ForeignKey(Hospital, verbose_name="Заклад", related_name="hospital",
                                 on_delete=models.SET_NULL, null=True)
    doctor = models.ForeignKey(Employer, verbose_name="Лікар", related_name="docto",
                               on_delete=models.SET_NULL, null=True)
    day = models.CharField("Дата та час", max_length=100)

    class Meta:
        verbose_name = "Запис на прийом"
        verbose_name_plural = "Записи на прийом"
