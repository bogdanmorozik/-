from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic.base import View
from django.contrib.auth import authenticate
from .forms import UserForm, UserForm2, LoginForm, EmployerForm, Login2Form, EmployerForm2, AppointmentForm,\
    VaccinaForm, VaccinationsForm, HistoryForm, UserSearchForm
from .models import User, Employer, Appointment, History, Hospital


def index(request):
    return render(request, 'portal/index.html')


def contacts(request):
    return render(request, 'portal/contacts.html')


def forgot_password(request):
    return render(request, 'portal/forgot_password.html')


def rules(request):
    return render(request, 'portal/rules.html')


def hospital(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    hospital = Hospital.objects.all()
    return render(request, 'portal/hospital.html', {"named": named, "hospital": hospital})


def vaccine(request):
    loginu = login
    nameu = User.objects.filter(login=loginu)
    form = VaccinaForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/acc_pat')
        else:
            print('error')
    form = VaccinaForm()
    return render(request, 'portal/vaccine.html', {'forms': form, "nameu": nameu})


def vaccine_doctor(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    form = VaccinaForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/acc_doc')
        else:
            print('error')
    form = VaccinaForm()
    return render(request, 'portal/vaccine_doctor.html', {'forms': form, "named": named})


def appointment(request):
    loginu = login
    nameu = User.objects.filter(login=loginu)
    nameu2 = User.objects.get(login=loginu).id
    nameu3 = get_object_or_404(User, pk=nameu2)
    form = AppointmentForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            new_form = form.save(commit=False)
            new_form.name = nameu3
            new_form.save()
            return redirect('/acc_pat')
        else:
            print('error')
    form = AppointmentForm()
    return render(request, 'portal/appointment.html', {'forms': form, "nameu": nameu})


def about_project(request):
    return render(request, 'portal/about_project.html')


def edit_doctor(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    form = EmployerForm2(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/login')

        else:
            print('error')
    form = EmployerForm2()

    data = {
        'forms': form,
    }
    return render(request, 'portal/edit_doctor.html', {"named": named, 'forms': form})


def recipe_doctor(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    form = VaccinationsForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/acc_doc')
        else:
            print('error')
    form = VaccinationsForm()
    data = {
        'forms': form,
    }
    return render(request, 'portal/recipe_doctor.html', {"named": named, 'forms': form})


def search_patient(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    form = UserSearchForm(request.POST)
    if request.method == 'POST':
        nameu = request.POST.get('name', '')
        if User.objects.filter(name=nameu).exists():
            print('holla')
            nameu2 = User.objects.filter(name=nameu)
        else:
            print('Нема такого')
            return redirect('/search_patient.html')
        return render(request, 'portal/search_patient.html', {"nameu2": nameu2, "named": named, 'forms': form})
    return render(request, 'portal/search_patient.html', {"named": named, 'forms': form})


def recipe(request):
    loginu = login
    nameu = User.objects.filter(login=loginu)
    nameu2 = User.objects.get(login=loginu).id
    id_user = History.objects.filter(name_user=nameu2)
    return render(request, 'portal/recipe.html', {"nameu": nameu, "history": id_user})


def my_schedule(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    named2 = Employer.objects.get(login=logind).id
    doctor_id = Appointment.objects.filter(doctor=named2)
    return render(request, 'portal/My_schedule.html', {"named": named, "history": doctor_id})


def patients(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    named2 = Employer.objects.get(login=logind).id
    named3 = get_object_or_404(Employer, pk=named2)
    form = HistoryForm(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            new_form = form.save(commit=False)
            new_form.name_emloyer = named3
            new_form.save()
            return redirect('/acc_doc')

        else:
            print('error')
    form = HistoryForm()

    data = {
        'forms': form,
    }
    return render(request, 'portal/patients.html', {"named": named, 'forms': form})


def signup(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/login')

        else:
            print('error')

    form = UserForm()

    data = {
        'forms': form,
    }

    return render(request, 'portal/sign_up_pat.html', data)


def signupd(request):
    if request.method == 'POST':
        form = EmployerForm(request.POST)
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/login')

        else:
            print('error')

    form = EmployerForm()

    data = {
        'forms': form,
    }

    return render(request, 'portal/sign_up_doc.html', data)


def login(request):
    if request.method == 'POST' and 'btn1' in request.POST:
        global login
        login = request.POST.get('login', '')
        form = LoginForm(request.POST)
        if User.objects.filter(login=login).exists():
            print('holla')
            password = request.POST.get('password', '')
            if User.objects.filter(password=password).exists():
                print('holla2')
                return redirect('/acc_pat')
            else:
                print('Невірний пароль')
        else:
            print('Неправильний логін')

    form = LoginForm()
    data = {
        'forml': form,
    }
    if request.method == 'POST' and 'btn2' in request.POST:
        global login2
        login2 = request.POST.get('login', '')
        form2 = Login2Form(request.POST)
        if Employer.objects.filter(login=login2).exists():
            print('holla')
            password2 = request.POST.get('password', '')
            if Employer.objects.filter(password=password2).exists():
                print('holla2')
                return redirect('/acc_doc')
            else:
                print('Невірний пароль')
        else:
            print('Неправильний логін')
    form2 = Login2Form()
    data2 = {
        'form2': form2,
    }
    return render(request, 'portal/login.html', {'forml': form, 'form2': form2})


class UserView(View):

    def get(self, request):
        nameu = User.objects.filter(login='admin@gmail.com')
        return render(request, "registration/login.html", {"nameu": nameu})


def accpat(request):
    loginu = login
    nameu = User.objects.filter(login=loginu)
    nameu2 = User.objects.get(login=loginu).id
    id_user = History.objects.filter(name_user=nameu2)
    return render(request, "portal/acc_pat.html", {"nameu": nameu, "history": id_user})


def accdoc(request):
    logind = login2
    named = Employer.objects.filter(login=logind)
    return render(request, "portal/acc_doctor.html", {"named": named})


def edituser(request):
    loginu = login
    nameu = User.objects.filter(login=loginu)
    form = UserForm2(request.POST)
    if request.method == 'POST':
        if form.is_valid():
            print('holla')
            form.save()
            return redirect('/login')

        else:
            print('error')
    form = UserForm2()

    data = {
        'forms': form,
    }
    return render(request, "portal/edit.html", {"nameu": nameu, 'forms': form})
