from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    path('contacts.html', views.contacts),
    path('rules.html', views.rules),
    path('about_project.html', views.about_project),
    path('appointment.html', views.appointment),
    path('vaccine.html', views.vaccine),
    path('patients.html', views.patients),
    path('My_schedule.html', views.my_schedule),
    path('vaccine_doctor.html', views.vaccine_doctor),
    path('recipe_doctor.html', views.recipe_doctor),
    path('edit_doctor.html', views.edit_doctor),
    path('forgot_password.html', views.forgot_password),
    path('login', views.login),
    path('acc_pat', views.accpat),
    path('acc_doc', views.accdoc),
    path('sign_up', views.signup),
    path('sign_up_d', views.signupd),
    path('login2', views.UserView.as_view()),
    path('edit', views.edituser),
    path('search_patient.html', views.search_patient),
    path('recipe.html', views.recipe),
    path('hospital', views.hospital)
]
