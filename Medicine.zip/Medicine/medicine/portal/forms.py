from .models import User, Employer, Appointment, Vaccina, Vaccinations, History
from django.forms import ModelForm, TextInput, Textarea, Select


class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['name', 'birthday', 'phone', 'id', 'adress', 'login', 'gender', 'password']
        widgets = {
            "name": TextInput(attrs={
                'class': 'text',
                'required': "",
                'placeholder': 'ПІБ',
                'id': 'marg'
            }),
            "birthday": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Дата народження',
                'required': "",
            }),
            "phone": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Телефон',
                'required': "",
                'maxlength': '13',
                'id': 'marg'
            }),
            "id": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Індетифікаційний код',
                'required': "",
                'id': 'marg'
            }),
            "adress": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Адрес',
                'value': '',
                'required': "",
                'id': 'marg'
            }),
            "login": TextInput(attrs={
                'type': 'email',
                'class': 'text',
                'placeholder': 'Email',
                'required': "",
                'id': 'marg'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'text w3lpass pass hiden',
                'placeholder': 'Повторіть пароль',
                'required': "",
                'id': 'password-check',
                'name': 'password-chek',
            }),
            "gender": Select(attrs={
                'class': 'text',
            }),

        }


class UserForm2(ModelForm):
    class Meta:
        model = User
        fields = ['name', 'birthday', 'phone', 'id', 'adress', 'gender', 'password']
        widgets = {
            "name": TextInput(attrs={
                'class': 'text phone',
                'required': "",
                'placeholder': 'ПІБ',
                'id': 'marg',
            }),
            "birthday": TextInput(attrs={
                'class': 'text',
                'required': "",
                'placeholder': 'Дата народження',
            }),
            "phone": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Телефон',
                'required': "",
                'maxlength': '13',
                'id': 'marg',
            }),
            "id": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Індетифікаційний код',
                'required': "",
                'id': 'marg'
            }),
            "adress": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Адрес',
                'value': '',
                'required': "",
                'id': 'marg'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'text w3lpass pass hiden',
                'placeholder': 'Повторіть пароль',
                'required': "",
                'id': 'password-check',
                'name': 'password-chek',
            }),
            "gender": Select(attrs={
                'class': 'text',
            }),

        }


class EmployerForm(ModelForm):
    class Meta:
        model = Employer
        fields = ['name', 'birthday', 'phone', 'id', 'adress', 'login', 'gender', 'password', 'speciality']
        widgets = {
            "name": TextInput(attrs={
                'class': 'text ',
                'required': "",
                'placeholder': 'ПІБ',
                'id': 'marg'
            }),
            "birthday": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Дата народження',
                'required': "",
            }),
            "phone": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Телефон',
                'required': "",
                'maxlength': '13',
                'id': 'marg'
            }),
            "id": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Індетифікаційний код',
                'required': "",
                'id': 'marg'
            }),
            "speciality": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Спеціальність',
                'required': "",
                'id': 'marg'
            }),
            "adress": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Адрес',
                'value': '',
                'required': "",
                'id': 'marg'
            }),
            "login": TextInput(attrs={
                'type': 'email',
                'class': 'text',
                'placeholder': 'Email',
                'required': "",
                'id': 'marg'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'text w3lpass pass hiden',
                'placeholder': 'Повторіть пароль',
                'required': "",
                'id': 'password-check',
                'name': 'password-chek',
            }),
            "gender": Select(attrs={
                'class': 'text',
            }),

        }


class EmployerForm2(ModelForm):
    class Meta:
        model = Employer
        fields = ['name', 'birthday', 'phone', 'id', 'adress', 'gender', 'password', 'speciality']
        widgets = {
            "name": TextInput(attrs={
                'class': 'text phone',
                'required': "",
                'placeholder': 'ПІБ',
                'id': 'marg'
            }),
            "birthday": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Дата народження',
                'required': "",
            }),
            "phone": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Телефон',
                'required': "",
                'maxlength': '13',
                'id': 'marg'
            }),
            "id": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Індетифікаційний код',
                'required': "",
                'id': 'marg'
            }),
            "speciality": TextInput(attrs={
                'class': 'text',
                'placeholder': 'Спеціальність',
                'required': "",
                'id': 'marg'
            }),
            "adress": TextInput(attrs={
                'class': 'text phone',
                'placeholder': 'Адрес',
                'value': '',
                'required': "",
                'id': 'marg'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'text w3lpass pass hiden',
                'placeholder': 'Повторіть пароль',
                'required': "",
                'id': 'password-check',
                'name': 'password-chek',
            }),
            "gender": Select(attrs={
                'class': 'text phone',
            }),

        }


class LoginForm(ModelForm):
    class Meta:
        model = User
        fields = ['login', 'password']
        widgets = {
            "login": TextInput(attrs={
                'type': 'email',
                'class': 'fadeIn second',
                'placeholder': 'login',
                'required': "",
                'id': 'login'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'fadeIn third',
                'placeholder': 'password',
                'required': "",
                'id': 'password'
            }),
        }


class Login2Form(ModelForm):
    class Meta:
        model = Employer
        fields = ['login', 'password']
        widgets = {
            "login": TextInput(attrs={
                'type': 'email',
                'class': 'fadeIn second',
                'placeholder': 'login',
                'required': "",
                'id': 'login'
            }),
            "password": TextInput(attrs={
                'type': 'password',
                'class': 'fadeIn third',
                'placeholder': 'password',
                'required': "",
                'id': 'password'
            }),
        }


class AppointmentForm(ModelForm):
    class Meta:
        model = Appointment
        fields = ['town', 'name', 'hospital', 'doctor', 'day']
        widgets = {
            "town": TextInput(attrs={
                'placeholder': 'Місто',
                'class': 'selected_style'
            }),
            "name": TextInput(attrs={
                'value': "1",
                'hidden': 'true'
            }),
            "specialiti": TextInput(attrs={
                'placeholder': 'Спеціальність',
                'class': 'selected_style'
            }),
            "day": TextInput(attrs={
                'placeholder': 'Дата та час',
                'type': 'datetime-local',
                'class': 'selected_style'
            }),
            "hospital": Select(attrs={
                'class': 'selected_style'
            }),
            "doctor": Select(attrs={
                'class': 'selected_style'
            }),

        }


class VaccinaForm(ModelForm):
    class Meta:
        model = Vaccina
        fields = ['town', 'name', 'hospital', 'day']
        widgets = {
            "town": TextInput(attrs={
                'placeholder': 'Місто',
                'class': 'selected_style'
            }),
            "name": TextInput(attrs={
                'placeholder': 'ПІБ',
                'class': 'selected_style'
            }),
            "day": TextInput(attrs={
                'placeholder': 'Дата та час',
                'type': 'datetime-local',
                'class': 'selected_style'
            }),
            "hospital": Select(attrs={
                'placeholder': 'Лікарня',
                'class': 'selected_style'
            }),
        }


class VaccinationsForm(ModelForm):
    class Meta:
        model = Vaccinations
        fields = ['id_vaccination', 'name_vaccination']


class HistoryForm(ModelForm):
    class Meta:
        model = History
        fields = ['name_user', 'number', 'name', 'name_emloyer', 'vaccinations', 'diagnos', 'diagnos2']
        widgets = {
            "name_emloyer": TextInput(attrs={
                'hidden': 'true',
                'value': '1'
            })
        }


class UserSearchForm(ModelForm):
    class Meta:
        model = User
        fields = ['name']
        widgets = {
            "name": TextInput(attrs={
                'placeholder': 'Введіть ПІБ пацієнта'
            })
        }
