from django.contrib import admin
from .models import User, Employer, Hospital, Vaccinations, History, Vaccina, Appointment


admin.site.register(User)
admin.site.register(Employer)
admin.site.register(Hospital)
admin.site.register(Vaccinations)
admin.site.register(History)
admin.site.register(Vaccina)
admin.site.register(Appointment)
